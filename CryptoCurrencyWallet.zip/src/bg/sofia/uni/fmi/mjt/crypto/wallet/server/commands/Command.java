package bg.sofia.uni.fmi.mjt.crypto.wallet.server.commands;

@FunctionalInterface
public interface Command {
    String execute();
}
