package bg.sofia.uni.fmi.mjt.crypto.wallet.server.models;

public record User(String username, String password, Wallet wallet) {

}
