package bg.sofia.uni.fmi.mjt.crypto.wallet.server.models;

public record CryptoOffering(String assetId, String name, double priceUsd, double volumeUsd) {
}
