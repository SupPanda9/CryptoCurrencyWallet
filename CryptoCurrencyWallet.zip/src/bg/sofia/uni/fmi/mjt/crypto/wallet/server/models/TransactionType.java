package bg.sofia.uni.fmi.mjt.crypto.wallet.server.models;

public enum TransactionType {
    DEPOSIT, BUY, SELL
}
